//------------------------------------------------
//		gameOfLife.h
//	Arthur Benemann 
//						27/05/2011
//------------------------------------------------
//  
//	Description:
//
//-------------------------------------------------

void gameOfLife(unsigned char key);
void randomizeScreen(int seed, int n);
